# Endian
Endian is for byte orientation not **bits**
## Little Endian
Right to Left
[ D, R, O, W]
[ 0, 0, 0, 15]
Writes Numbers the same for both
if we reverse the number it could be represenative of 4 byte integer.
## Big Endian
Left to right
[W,O,R,D]
[0,0,0,15]

To combat flipping between Endieness there is a header often includes to keep track of the what the data tpye iss


# Expanding Opcode
Opcode Opcode or instructions are 
$(n+k)$ 
n = single n bit address
k = k-bits in op code 

| bits (ad)           | 1s    |
| ------------------- | ----- |
| 15 Instruction (3)  | 0-3   |
| 14 Instructions (2) | 4-6   |
| 31 Instructions (1) | 7-11  |
| 16 Instructions (0) | 12-16 |
How many addresses, What is the address
	First recreate table above by looking at diagram, for each range count how many 1s appear in each bracket.

	Now we can look at 
How many instructions, Why? 
	How many iterations we have of the nonfixed instruction bits
	
1111 1111 0000 1010
0010 1000 1111 1010
Trade off by increasing k bits and reducing n bits (more instructions, less address)
>Consider a 16 bits long instruction, and addresses are 4 bit long
![[Pasted image 20241108104158.png]]

With a 16 bit long instruction, and 4 bit addresses
### 3-Address Instruction
![[Pasted image 20241108104458.png]]
>0000 xxxx yyyy zzzz
...
1111 xxxx yyyy zzzz 
There are 15 3-address instruction
### 2-Address Instructions
![[Pasted image 20241108104507.png]]
14 2 address instruction 
### 1-Address Instructions
![[Pasted image 20241108104520.png]]
31 1-address instructions
### 0-Address Instructions
![[Pasted image 20241108104531.png]]
16 0-address instruction

## Summary
We can shift n and k to $(k-2)$ and $(n+2)$ if we wanted to 
For each bit we shift we lose operations 

# Bus Arbitration
Managing access to a shared communication bus among multiple devices or processors
## Centralized
Arbiter: Control unit for granting bus master
Single arbiter/control unit that manages access the buss
## Decentralized 
Decides by themselves
Halloween
## Proximity
Goes who is closest to the bus
## Priority
Each device is assigned a priority level 
## Greedy
Provides bus access to the device that request it first, and continues to provide granting access to it as long as it needs it.
# SSD
![[Pasted image 20241108110154.png]]

The programming Voltage will place a negative charge into the Floating gate to store a (1) in binary. The test tap will pass a charge into the source, and if the negative charge is present then the drain 

Compare SSD to HDD
Pros:
- HDD
	- Cheap
- SSD
	- Faster
Cons:
- HDD
	- Moving Parts
	- Require Defragment
- SSD
	- More Expensive
	