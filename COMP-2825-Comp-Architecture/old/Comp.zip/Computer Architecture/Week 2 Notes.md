# Definitions:
Clocks: Anything that can be toggled between on/off
Clock cycle: defined in Hz ie 100MHz 10^6
Period = 1/frequeny; 1/1M = 1 microsecond = 10^-6

The clock cycle of does not mean all actions are matching the clock cycle
Such as a TV show clock cycle is 30minutes, but not all programming is 30 minutes long/

## Von Neumann Datapath
The inside of the CPU (The right):
page 57 diagram
![[Pasted image 20240915162638.png]]
Line = Busses
Box = Register

Things to now

Program Coutner ("PC"):
- Stores main memory address of the next instruction to FDE
Instruction Register ("IR"):
- Holds instructions
Arithmetic Logic Unit  (ALU):
- Does math

Read 63-64
# RISC Design Principles
1. All Instructions Are directly executed by <u>Hardware</u>
	- Complex and Expensive
2. Issue instructions as fast/often as possible
	- Complex and Expensive
3. Instructions should be easy to decode
	- Backward Compatibility
	- Same-sized instructions
4. . Only <u>loads</u> and **<u>stores</u>** should reference memory
	- Cannot avoid going to Main-Memory (RAM)
5. . Provide Plenty of Registers
	- Expensive
## Goal is to prevent the CPU from starving
# RISC vs CISC Architecture
Reduced Instruction Set Computer (RISC)
- Fewer, and simpler instructions
Complex Instruction set Computer (CISC)
- More, and more complex instructions: e.g. implement the most common instructions directly in hardware (no interpretation required), even the complex ones

Modern Computers are a mix of: mostly RISC and some CISC
# How does Cache work in CPU?
![[Pasted image 20240915165141.png]]
CPU only request a single word at a time.
When CPU requests for 6000, and it goes to cache. 
The cache will always be checked for "6000", and in the case that cache does not have "6000" it will grab an area around 6000, such as 5998-6006 so that if the CPU requests for the next address cache can provide it faster

# Spatial and Temporal Locality
Spatial Locality,
- When address 6000 is pulled from Main memory, its neighbours are also brough in with pulling in the data as a "Block". The neighbours are Spatially local to 6000
Temporal Locality
- Cache will try to keep recently called words and store it in the cache, so that in the case the CPU needs the value again it can provide it quickly.
- The memory is considered Temporal when it is re-refereed again soon after its first call.


Interpreter:
- Any Software program that FDE the instructions of another program. That outpu is another program that is simpler to run. This takes time though, this is cheaper than have hardware run the original (more complex, higher-level) program and it is cheapre than having hardware do the conversion.
Translation = Compiling
# Pipelining

![[Pasted image 20240915171710.png]]

Instructional Latency: The total time an instruction spends in the pipeline 66 minutes / Car
Instructional Bandwidth: The number of Instructions finishing per unit time: e.g. 1 car/60 minutes. 
Bandwidth is calculated by 1 / slowest stage time

Ideal Pipeline: has no bottlenecks; no slowest stages; all stages take the same amount of time
![[Pasted image 20240915172635.png]]
A longer (deeper) pipeline can increase bandwidth and may lengthen, shorten, or not affect the latency
Question:
What are the latency and bandwidth for this assembly line:
Stages are
15 minutes, 4 minutes, 1 minute, 24 minutes, 16 minutes,  120 seconds

latency:$15 + 4 + 1 + 24 + 16 + 2 = 62$ j62 mins / unit
Bandwidth 1/24 minutes

Quiz will use ms,us,ns,ps

Question:
What are the bandwidth and latency for a pipeline with four stages which take .01 milli-seconds, 250,000 nanoseconds, 30 microseconds, and 2 milliseconds.
