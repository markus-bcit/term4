# Review
## Hamming Code
DW 1011 Even $2^{5}$
`_ _ 1 _ 0 1 1 _ 1`

Even though this Code word is $2^{9}$ bits there is only $2^{5}$ valid arrangements CW since each data word has exactly one valid arrangement

The smallest distance = Hammning Distance
Smallest number of changes when you change one bit
>"Every data word change carries **at least** a 2 bit change"