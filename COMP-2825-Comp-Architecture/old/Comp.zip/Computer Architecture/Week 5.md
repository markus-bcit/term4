
# Evolution of Gates
## SR Latch
![[th-3374596114.jpg]]
### Pro
Almost perfect for what we want for a state machine
### Cons
Inconsistant state when S = R = 1
Breaks because Q and $!{Q}$ = 1

## Unclocked D latch
![[unclocked-d-latch1-l-3489123242.jpg]]
Impossible to get 
S = R = 1  and S = R = 0
Note* S = R = 1 is good
S= R = 0 =awful 
### Pros

### Cons
No Memory, can't set to Q to 0

### Improvements made
## Clocked D
![[D-latch-circuit-and-nor-1-3241225502.png]]
![[Pasted image 20241004110432.png]]
### Pros
Works as single bit memory
### Cons
**Only** works for one bit memory

### Improvement
Allows us to handle if both are 0 with and gate
and prevent if both S and R are 0

## D flipflop

### Rising edge trigger (Pulse generator)
![[Pasted image 20241004111303.png]]

Due to timing when clk changes there will be a true signal for a short period of time.

# Tri-state noninverting buffer
![[Pasted image 20241004114119.png]]
Input C is like a valve
Output
0,1, nothing

# ALU
Lets you do full addition - 
## Logical unit
Checks AND OR NOT, ADDITION

## Function Decoder (F,F1)
And or not addition

Multiplexer
Combinational circuit,
for ever input has a specific output for all 3 outputs
