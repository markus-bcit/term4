# Von Neumann Datapath
Refer to Diagram in notes
Program Counter Stores the Main memory address of the next instructions 
Instruction Register - Stores Current Instruction
MDR - Main Data Register - 
MAR - Main Address Register - 


Steps to Read from memory
 PC loaded with 321
1. PC puts on bus (loads into b auto) load into MAR
2. MAR read is told to wait (**relatively long time**)
	1. While waiting Add 1 using ALU
	2. Store Z 
	3. Clear Bus and store in PC
3. MAD -> CPU Bus -> IR
	1. Example: Add R1,R2,R3
4. Fetch R1 into bus -> b and y
5. Fetch R2 into bus goes into Bus -> B calculates into ALU -> Z
7. Empty Bus and load Z into R3



## Write the Microprogram
> FDE 
> "ADD R5,R3,R1,R2"

1. PC OUT, MAR IN, RD, CLEAR Y, Z IN, SET C N,  
2. Z OUT, PC IN, WMFC
Fetch includes Increment 
Fetches Address of instructions (PC) and read from memory, during waiting for memory to read we should increment the program counter using the ALU. Store it in PC then.. await WMFC

3. MDR OUT, IR IN
Takkes instruction from memory and load into instruction register, which feeds into instruciton decoder (ADD r5 r3 r1 r2)
4. R5 OUT, Y IN,
5. R3 OUT,ADD, Z IN,
6. Z OUT, Y IN
7. R1 OUT,ADD, Z IN
8. ZOUT, R2 IN

>Write the Microcode to FDE to Add R1,(R2),R3
(R2) = Address

1. PC OUT, MAR IN, RD, CLEAR Y, Z IN, SET Cin
2. Z OUT, PC IN, WMFC
3. MDR OUT, IR IN
4. R2 OUT, MAR IN, RD
5. R1 OUT, Y IN, WMFC
6. MDR OUT, ADD, Z IN
7. Z OUT, R3 IN
>Write the Microcode to FDE to Add R1,((R2)),R3
(R2) = Address

1. PC OUT, MAR IN, RD, CLEAR Y, Z IN, SET Cin
2. Z OUT, PC IN, WMFC
3. MDR OUT, IR IN
4. R2 OUT, MAR IN, RD
5. R1 OUT, Y IN, WMFC
6. MDR OUT, MAR IN, RD, WMFC
7. MDR OUT, ADD, Z IN
8. Z OUT, R3 IN

>Write the MicroCode to FDE to ADD R0,(R2),(R3)

1. PC OUT, MAR IN,RD, CLEAR y, Z IN,SET CIN
2. Z OUT, PC IN, WMFC
3. MDR OUT, IR IN
4. R2 OUT, MAR IN, RD,
5. R0 OUT, Y IN, WMFC
6. MDR OUT, ADD, Z IN
7. Z OUT, MDR IN
8. R3 OUT, MAR IN, WRITE, WMFC, END

