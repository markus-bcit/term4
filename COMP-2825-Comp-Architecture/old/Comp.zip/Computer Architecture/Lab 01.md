## Question 1:
>Explain each of the following terms in your own words
> a. translation
> b. interpretation
> c. Virtual Machine

- Translation is defined as breaking down a HLL to a lower level language by use of a compiler this would generate a new file that is in a lower level language. HLL -> L0 as a seperate file
- Interpretation is a way to run HLL using an application in the LLL to read the HLL and execute L0 code in its place.
- A Virtual machine in context of this course is a synonmn for a Level. You can think of each Level being a "Virtual Machine" as it runs each level of code. 
## Answer:
1. It is when we are translating a high level language to a lower level language usualy done using a compiler all at onces
2. Interpreter is where we are converting a high level language to a lower lever language then executing it immediatley. `no compiler required no new programs is generated` 
## Question #4:
>Consider a multilevel computer in which all the levels are different. Each level has instructions that are `m` times as powerful as those of the level below it; that is, one level `r` instruction can do the work of `m` level `r - 1` instructions. If a level-1 program requires `k` seconds to run, how long would equivalent programs take at a levels 2,3, and 4, assuming n level r instructions are  required to interpret a single `r + 1` instruction
## Answer:
Level 4: $\frac{kn^{3}}{m^{3}}$ seconds
Level 3: $\frac{kn^{2}}{m^{2}}$ seconds
Level 2: $\frac{kn}{m}$ seconds
Level 1 : $k$ seconds
//Level 0: $\frac{km}{n}$?

## Bonus Lab Question
> Consider a computer with identical interpreters at levels 1,2, and 3. It takes an interpreter `n` instructions to fetch, examine, and execute one instruction. A level 1 instruction takes k nano seconds to execute. How long does it take at levels 2,3, and 4,

Since it is using the same identical interpreters we can assume factor `m` is identical there for m = 1

There for 
Level 4: $\frac{kn^{3}}{m}$ Nanoseconds
Level 3: $kn^{2}$ Nanoseconds
Level 2: $kn$ Nanoseconds
Level 1: $k$ Nanoseconds
	
>The performance ratio of the 360 model 75 was 50 times that of 360 model 30, yet the cycle time was only 5 times as fast. How do you account for this discrepancy.

1. There could more levels in the computer architecture meaning while there is a higher performance ratio there could be generating more lines of code that is required to be ran on the lowest level language.
	1. Since it was a factor of 10 perhaps there was some calculation error when calculating the M factor in each level. This could cause a factor by 10 being replicated in the solution