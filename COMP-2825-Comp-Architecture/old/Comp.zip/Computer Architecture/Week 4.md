# Mean Memory Access Time
Formula for Average memory Access Time: $C+(1-h)m$
C = Cache Time
h = Hit rate
m = memory
$1-h$ = Miss rate
>Assume Accessing Fridge is 1 min, and Store (Memory) is 60 minutes. With a hit rate of 80%

Best Case: 1 Minute
Worst Case: 61 Minute
Average Case: $1+.2\cdot60 = 13$ minutes

## Example using Caches

> Assume you have L1 Cache and it takes 4 ns to reach it.
> Main memory 50 ns to reach it
> What are the average time for 
> 70%, 90%, 0%, and 100% hit rate

$70\% = 4 + 0.3 \cdot 50 = 19$ nanoseconds
$90\% = 4 + 0.1 \cdot 50 = 9$ nanoseconds
$0\% = 4 + 1 \cdot 50 = 54$ nanoseconds
$100\% = 4 + 0 \cdot 50 = 4$ nanoseconds

>300 requests were made 200 hits to L1 60 hits to L2 the Rest to main memory
It takes 4 ns to reach L1, and 12 ns to L2, and 50 ns MM

What is mean memory access time
$\frac{(300\cdot4)+(100\cdot12)+(40\cdot50)}{300}=14.666$

>540 requests
>L1  2 ns 300 hits
>L2 10 ns 120 hits
>L3 20 ns 80 hits
>MM  80ns  rest 

$\frac{(540\cdot2)+(240*10)+(120*20)+(40*80)}{540}$
= $\frac{1040+2400+2400+3200}{540} = \frac{9080 \text{ nanoseconds}}{540 \text{ request}}$


# Harddrive
w
![[disk-structure.png]]
There are circles and single sided

Sector Contains
Header Footer
ECC 
Sector #

Sectors permeates through all the platters

Typical Spin rate is 7200 RPM
or 120 RPS
or 8.3 ms 
RPM / 60 = RPS
1/RPS = MS

Spin Rate = 7200 rpm = 8.3 ms / revolution
Spin rate = 5400 rpm = 11.1 ms / revolution
Spin Rate = 100800 rpm = 5.55 ms /revolution

Data is stored within a track in a sector
There are gap between sector for ECC metadata

4 platters 8 sector 4 tracks / platter

96 sectors
12 tracks
4 cylinders
1 HDD 
3 plattter
## Definition
Track = Ring of magnetic bits with a Radius
Platter = Disk
Sector = A slice of a 
Cylinder = Slice across platters of the same track = # of tracks

Seek Time =  time for the read/write heads to move the desired track
Rotational Latency = Wait for the desired sector to spin the under the read write head.
Avg Rotational Latency = half of rotation speed
If reading from full drive it doesn't have any rotational latency
Read (1 rotation)

## How is data read?
Assuming 3 platters reading from Sector A
Platter 1 would read Sector A
Then one full revolution 
Platter 2 would be read
Then one full revolution 
Platter 3 Would be read

## Reading data
Seek Time =  time for the read/write heads to move the desired track
Rotational Latency = Wait for the desired sector to spin the under the read write head.
Avg Rotational Latency = half of rotation speed
If reading from full drive it doesn't have any rotational latency
Read (1 rotation)

Move to A
Wait for Sector
Read - Read - Read
Move to B
Wait for Sector
Read - Read - Read

> How long does it take to read a disk with 10,000 cylinders, each containing four tracks of 2048 sectors? First, all the sectors of track 0 are to be read starting at sector 0, then all the sectors of track 1 starting at sector 0, and so on. The rotation time is 10 msec, and a seek takes 1 msec between adjacent cylinders and 20 msec for the worst case. Switching between tracks of a cylinder can be done instantaneously.

Steps:
1. Move read head to Track 0: Worst case = 20 ms
2. Wait for Sector 0: 10ms /2 = 5ms
3. Read All 4 Sectors: 4* 10 ms
4. Move RW Head: 1 ms
5. Wait for Sector 0: 9ms

Repeat step 3-5 * 10000 times
