Basic Error-Correcting Code Theory
### Definitions
Big Endian
Little Endian
Data word
- The raw data word we want to protect and store without erros
Codeword
- The data word, with extra bits added into it. The extra bits are known as parity bits, check bits, or redundant bits. These extra bits allow us to **detect/correct**.
Hamming code is an official protocol for error detection and correction

some errors have so many individual errors they begin to look like another valid response

**Code** = Dictionary (Set of valid words)

The Trade off between adding more bits in a word is that there is a trade off between **clarity** and **efficiency**
more bits = less efficiency more clarity
less bits = more efficiency more clarity

Having a code with many valid words and little invalid makes it useless
 We achieve better codes by making the code **longer and the words more different**


**Hamming Distance** - The **minimum** number of bis between **any**  2 valid words in a code.
A code with Hamming Distance of h bits can **<u>detect</u>** up to **less than h** bit errors (anything h amonut of errors) 
A code with Hamming Distance of h bits can **<u>correct</u>*** up to **less than h/2** bit errors (not equal to h/2)

000 0000
1111 1111
Hamming distance of 8 bits
Cannot correct 5,6,7,8 bit errors

New Code:
000000
111111
000011

Hamming Distance of 2 bits.


**WE want LARGE GAPS between valid words**

|  HD  | ED (# bit erros detectable) | EC(# bit errors correctable) |
| :--: | :-------------------------: | :--------------------------: |
|  8   |        Up to 7 bits         |           Up to 3            |
| 256  |          1 to 255           |        less than 128         |
|  1   |              0              |              0               |
|  H   |          Up to H-1          |        Less than H/2         |
|  21  |             20              | Less than 10.5 (10 or fewer) |
| 8000 |      Anything but 8000      |        Less than 4000        |
|  17  |          Up to 16           |        8 bit or fewer        |
|  10  |           9 bits            |         Less than 5          |

# Actual Hamming ECC Examples

Create the Hamming codeword for the following data word: 001110
using EVEN parity

Codeword: `_ _ _ _ _ _`
Assuming we miss information in 1,2,4,8th bit

`_ _ 0 _ 0 1 1 _ 1 0
0 on bit 3 = 2 +1
0 on bit 5 = 4 + 1
1 on bit 6 = 4 + 2
1 on bit 7 = 4 + 2 + 1
1 on bit 9 = 8 + 1
0 on bit 10 = 8 + 2 


Those bits are numbered as powers of 2: 1,2,4,8,16
are called **parity bits** (aka check bits, redundant bits, or Hamming Bits)

The parity bits store the information of adding all the values of the bit where the power was used

1st bit = 0 + 0+ 1 + 1 = 2 (store as 0)
2st bit = 0 + 1 + 1 + 0  = 2 (store as 0)
4th bit = 0 + 1 + 1 = 2 (store as 0)
8th bit = 1+ 0 = 1 

After Adding up to store it it would be `0000 0111`

Example 2:

> Create the Hamming Codeword for the dataword 1000 with Even Parity

1000
`_ _ 1 _ 0 0 0 `
1 = 3 = 2 + 1
0 = 5 = 4 + 1
0 = 6 = 4 + 2 
0 = 7 = 4 + 2 + 1

`1 1 1 0 0 0 0`
What if it is odd?
Just **flip** the parity bits
`0 0 1 1 0 0 0`

Example 3:
> Codeword: 010101011

Even: 

`1 0 0 0 1 0 1 1 0 1 0 1 1`
Odd :
`0 1 0 1 1 0 1 0 0 1 0 1 1`


> The following Hamming codeowrd was created using EVEN parity. Are there errors? If so, Where? What was the original dataword supposed to have been?

`0 1 0 0 1 0 1 1 0 1 0 1 1`

first step check if parity bits 1, 2 ,4, 8 shuld have the values 0 1 0 1

1 = Should be 1 
2 = Should be 0
4 = Ok
8 = Ok 

Yes there are errors, bits 1 and 2 show that bi 1 + 2 = 3, bit 3 is an error, bit 3 should be 1.

To recover the original dataword we remove the parity bits, flip bit 3
Original Word: ` 1 1 0 1 1 0 1 1 `
