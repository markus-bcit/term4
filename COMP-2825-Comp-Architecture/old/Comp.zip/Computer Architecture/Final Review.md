# Von Neuman Datapath
## Goals:
1. [x] Draw from memory 
2. [x] Be able to Write Microcode for instruction

# 4 Topics
## Endian
- [x] Big Endian
- [x] Small Endian
## Instruction Code
- [x] Explain
## Bus Arbitration
- [x] Centralized
- [x] Decentralized
- [x] Proximity
- [x] Priority
- [x] Greedy
## SSD
- [x] Pros/Cons

# TLW
- [x] Calculate TLW
- [x] Calculate TLW Values at MM addr
- [x] Find Associate in block
- [x] Total Blocks
- [ ] Find TSW for etc..
- [ ] Given Cache do reads