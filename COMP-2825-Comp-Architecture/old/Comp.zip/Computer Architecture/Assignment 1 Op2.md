Currently using GitLab (Premium License per dev)
Jira
Confluence
Software is on AWS

looking for SaaS optoin, but need LDAP for SSo and management of user
Auditlogging


Requirements
- SaaS
- LDAP for SSO + Management of users
- Audit logging
- 2-FA
- Technical support with quick turn around
- Automated CI pipelines for UI tests
- Security Analysis on python application
- Stat Code Analysis
- Multiple application support 
- Containers and Kubernetes
- AWS integration
- Docker Container Registry and 3rd party registry dockerhub
Budget
- 300 USD per developer per year
Research on 
Gitlab CI
Bamboo
Circle CI
AWS Code Pipeline