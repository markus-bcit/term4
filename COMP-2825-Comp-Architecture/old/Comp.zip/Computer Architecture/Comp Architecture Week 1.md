# Textbook Pages of Diagram
If you understand these pages then it will be easy
### Chapter 1
- 5*, 18, 50* and JVN
### Chapter 2 
- 57, 88, 75*, 82
### Chapter 3
- 161b*, 164, 165, 167, 173, 176, 193* ,195
### Chapter 4
- 245,292,307****
### Chapter 5
- 366
### Chapter 7
- ASM (Team of 3 presentation)


# Jon von Neumann
Great guy
made lots of computers and mathematics

lots of compromises in your computer :
- Need to be cheap to produce
- Need to be Simple
- Need to be backwards compatible
	- runs be able to run older programs

### Definitions:
Bit 
- 0 or a 1 
Byte
- 8 bit word 
Word:
- The size of a word is determined by a register
Register:
- Cpu Memory that by definition stores a single word

64-bit vs 32-bit computers: 2^ 64 = 2^32 * 2^32
cpu: fetches, decode, and executes instructions: FDE cycle
ram:  aka "Main Memory"
cache: faster, closer to CPU, smaller, more expensive memory than ram
bus: shared/common electrical pathway between devices to transfer data

2^6 =64
2^10 = 1024 aka 1k
2^16  = 2^6 * 2^10 = 64k ANSWER THIS WAY IN CLASS
2^17 = 128K

2^20 = 1M
2^30 = 1G
2^40 = 1T

2^38 = 256G
2^29 = 512M
2^45 = 32T

2^32 = 4G

interpretation: convert one instruction from a high-level-language (HLL) program to the equivalent set of LLL instructions, then execute that, then repeat for next instruction

compilation: convert the entire HLL program to equivalent LLL program, then execute that program and you don't need the original program.

