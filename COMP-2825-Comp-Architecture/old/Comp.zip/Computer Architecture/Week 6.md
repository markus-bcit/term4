# Timing Diagram
![[Pasted image 20241011103811.png]]
Address : Specifies read/write from CPU
Data 
	Read = Controlled by memory
	Write = Controlled by CPU
MREQ = time it specifies when read/write request start to stop
RD = Flag to control if it is a read or write action
wait = Controlled by memory

Tad = Time to give address
Tds = Time for data to be stable (slightly ahead of reading)

## Frequency Calculation
100 MHz = 10ns/cycle
1 GHz = 1ns /cycle

| Freq (Hz) | Clock Cycle  |
| :-------: | :----------: |
|   1 GHz   |     1 ns     |
|  100 MHz  |     10ns     |
|  25 MHz   |     40ns     |
|  400 Khz  |    2.5 us    |
|   20 Hz   |    50 ms     |
|  200 MHz  |     5ns      |
|  20 KHz   | 50us (micro) |
|   4 Hz    |    250 ms    |

15 nsec memory
falling edge

## Steps
1. CPU ask for memory at address and specify a Read
2. Memory replies Wait
3. Memory Replied No Wait
4. Memory Responds Data


## Questions
>How long does memory have to provide the requested word from when the address is stable?

Answer From the end of Tad until the beginning of Tds
2.5 cycles * 10 ns /cycle = 25 ns - Tad -Tds
25 ns -4ns - 2ns = 19 ns

The book told us the memory can fetch a word in 15ns from having a stable address so we have 4ns to spare

>Why couldn't it be available in T2 falling's edge

In order to have fetched the word Tds Nanosecods before T2's Falling edge, the memory would have just 9 ns (19-10)

$\text{\#cycles} * \frac{10ns}{cycle} - Tad - Tds$

> How long does memory have to fetch from when the address is stable:
> 200 MHz bus frequency,
> Tad = 2ns,
> Tds = 1ns,
> 3 wait states

5ns/cycles
4.5* 5ns - 2 -1 = 19.5

> B) with zero wait states?

1.5 cycle * 5ns - 2- 1 = 4.5



>How long does memory have to fetch the word **From when the memory request is asserted** with one wait state as shown
>100 Mhz Bus

To solve these problems, we must solve them twice then pick the worst case as the final answer

1. Using Tm
```
2 cycles ( falling edge T1 to falling edge T3)
- Tds - Tm 

10 ns * 2 cycles - Tm - Tds =
20 ns - 3ns -2 ns = 15ns
```
2. Using Tml
```
2.5 cycles (Rising Edge T1 to falling edge T3) 
- Tds - Tml - Tad
10ns * 2.5 cycles - Tad - Tml - Tds 
25 ns - 4 ns - 2ns  - 2ns = 17 ns
```
The finals answer to satisfy both the Tm and Tml conditions is the worst case out of 15 ns and 17ns:
15 ns (worse because they are deadlines)


> How long does memory have to Fetch
> 40 MHz bus
> Tad 4
> Tm  6 
> Tml 8 
> Tds 9
> 2 wait states
> A) from stable memory
> B) from memory request is made

Clock Cycle is 25 ns
1. Stable memory
	3.5 cycles - Tad -Tds
	3.5 * 25 ns - 4 -9 = 74.5ns
1. Memory Request is made
	1. Tml
		3.5 cycles - Tad - Tml - Tds
		3.5 * 25 - 8 - 9 - 4 = 66.5 ns
	1. Tm
		3 cycle * 25 - 6 - 9  60 ns
	Worse Case 60ns
