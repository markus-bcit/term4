# 4640 application 

This repository contains: 
- an example bun and htmx todo list app
- a Caddyfile 
- a service file

For instructions on setting everyting up see the assignment instructions provided in the course notes
