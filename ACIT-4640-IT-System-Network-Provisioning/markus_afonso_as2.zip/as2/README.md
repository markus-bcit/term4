[Video](https://youtu.be/y-7txoQ3aTo)
To run:
```bash
cd terraform/
terraform init
terraform apply
```
After deployed
```bash
cd ../ansible
ansible-playbook site.yml
```